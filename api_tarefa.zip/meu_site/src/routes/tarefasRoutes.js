const express = require('express');
const router = express.Router();

const tarefasController = require('../controllers/tarefasController');
const validateTarefa = require('../middlewares/validateTarefa');

// Rotas
router.get('/', tarefasController.listarTarefas);
router.post('/', validateTarefa, tarefasController.criarTarefa);
router.get('/:id', tarefasController.obterTarefaPorId); // Se implementado no controller
router.put('/:id', validateTarefa, tarefasController.editarTarefa);
router.patch('/:id/concluir', tarefasController.concluirTarefa);
router.delete('/:id', tarefasController.deletarTarefa);

module.exports = router;
