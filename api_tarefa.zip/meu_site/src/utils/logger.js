// src/utils/logger.js
const log = (message) => {
    console.log(`[LOG] ${message}`);
};

module.exports = { log };
