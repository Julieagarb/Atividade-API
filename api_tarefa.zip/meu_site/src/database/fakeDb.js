// src/database/fakeDb.js
let tarefas = [];

module.exports = { tarefas };
