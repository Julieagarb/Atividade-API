// src/controllers/tarefasController.js
const tarefasService = require('../services/tarefasService');
const logger = require('../public/utils/logger');

const criarTarefa = (req, res) => {
    const { titulo, descricao, concluida } = req.body;
    const novaTarefa = tarefasService.criarTarefa({ titulo, descricao, concluida });

    logger.log('Tarefa criada com sucesso.');
    res.status(201).json({ mensagem: 'Tarefa criada com sucesso!', tarefa: novaTarefa });
};

const listarTarefas = (req, res) => {
    const filtro = req.query.concluida;
    const tarefas = tarefasService.listarTarefas(filtro);

    res.status(200).json(tarefas);
};

const editarTarefa = (req, res) => {
    const { id } = req.params;
    const { titulo, descricao, concluida } = req.body;
    const tarefaAtualizada = tarefasService.editarTarefa(id, { titulo, descricao, concluida });

    if (!tarefaAtualizada) {
        return res.status(404).json({ mensagem: 'Tarefa não encontrada.' });
    }

    res.status(200).json({ mensagem: 'Tarefa atualizada com sucesso!', tarefa: tarefaAtualizada });
};

const concluirTarefa = (req, res) => {
    const { id } = req.params;
    const tarefa = tarefasService.concluirTarefa(id);

    if (!tarefa) {
        return res.status(404).json({ mensagem: 'Tarefa não encontrada.' });
    }

    res.status(200).json({ mensagem: 'Tarefa concluída com sucesso!', tarefa });
};

const deletarTarefa = (req, res) => {
    const { id } = req.params;
    const tarefaDeletada = tarefasService.deletarTarefa(id);

    if (!tarefaDeletada) {
        return res.status(404).json({ mensagem: 'Tarefa não encontrada.' });
    }

    res.status(200).json({ mensagem: 'Tarefa deletada com sucesso!' });
};

module.exports = { criarTarefa, listarTarefas, editarTarefa, concluirTarefa, deletarTarefa };
