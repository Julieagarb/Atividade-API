// src/services/tarefasService.js
const { tarefas } = require('../database/fakeDb');
const { v4: uuidv4 } = require('uuid');

const criarTarefa = ({ titulo, descricao, concluida }) => {
    const novaTarefa = { id: uuidv4(), titulo, descricao, concluida };
    tarefas.push(novaTarefa);
    return novaTarefa;
};

const listarTarefas = (filtro) => {
    if (filtro) {
        return tarefas.filter(tarefa => tarefa.concluida === (filtro === 'true'));
    }
    return tarefas;
};

const editarTarefa = (id, { titulo, descricao, concluida }) => {
    const tarefaIndex = tarefas.findIndex(t => t.id === id);
    if (tarefaIndex === -1) return null;

    tarefas[tarefaIndex] = { ...tarefas[tarefaIndex], titulo, descricao, concluida };
    return tarefas[tarefaIndex];
};

const concluirTarefa = (id) => {
    const tarefa = tarefas.find(t => t.id === id);
    if (!tarefa) return null;

    tarefa.concluida = true;
    return tarefa;
};

const deletarTarefa = (id) => {
    const tarefaIndex = tarefas.findIndex(t => t.id === id);
    if (tarefaIndex === -1) return null;

    return tarefas.splice(tarefaIndex, 1)[0];
};

module.exports = { criarTarefa, listarTarefas, editarTarefa, concluirTarefa, deletarTarefa };
