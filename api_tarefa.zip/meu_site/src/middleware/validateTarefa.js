// src/middlewares/validateTarefa.js
const Joi = require('joi');

const validateTarefa = (req, res, next) => {
    const schema = Joi.object({
        titulo: Joi.string().min(3).required().messages({
            'string.min': 'O título deve ter pelo menos 3 caracteres.',
            'any.required': 'O título é obrigatório.'
        }),
        descricao: Joi.string().required().messages({
            'any.required': 'A descrição é obrigatória.'
        }),
        concluida: Joi.boolean().required().messages({
            'any.required': 'O status da tarefa é obrigatório.'
        })
    });

    const { error } = schema.validate(req.body);

    if (error) {
        return res.status(400).json({ mensagem: error.details[0].message });
    }

    next();
};

module.exports = validateTarefa;
